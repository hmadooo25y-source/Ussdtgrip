# USSD Flow

تطبيق Android (Kotlin, minSdk 26) يشغّل سيناريوهات USSD متعددة الخطوات معرّفة في ملف JSON،
ويمكنه تكرارها على صفوف ملف CSV ثم تصدير النتائج.

## التشغيل
1. افتح المجلد في Android Studio (Koala أو أحدث) واتركه يزامن Gradle.
2. شغّل على جهاز حقيقي بشريحة SIM (المحاكي لا يدعم USSD).
3. من التطبيق: فعّل «خدمة Accessibility» ← امنح صلاحيتي الهاتف عند أول تشغيل ← «تحميل المثال» ← «تشغيل».

## كيف يعمل
- `mode: "api"` يستخدم `TelephonyManager.sendUssdRequest` (طلب/رد واحد فقط، ولا يدعم متابعة القوائم).
- `mode: "accessibility"` يطلب الرمز عبر `ACTION_CALL` ثم يقرأ نافذة USSD ويكتب الرد ويضغط «إرسال» عبر AccessibilityService. هذا ما يتيح القوائم متعددة الخطوات.
- `mode: "auto"` (الافتراضي): accessibility إن كانت الخدمة مفعّلة، وإلا api.
- الخدمة لا تقرأ أي شاشة إلا أثناء تشغيل سيناريو (`UssdBus.armed`) وتقتصر على حزم الهاتف/الاتصال المعلنة في `accessibility_service_config.xml`.

## صيغة السيناريو
الحقول العامة: `name, mode, simSlot (-1 افتراضي), stopOnError, delayBetweenRowsMs, variables, steps`.
في النصوص يمكن استخدام `${المتغير}`؛ أعمدة CSV تصبح متغيرات لكل صف.

| type | الحقول |
|---|---|
| dial | code, timeoutMs, retries, next |
| reply | text, timeoutMs (0 = لا تنتظر ردًا), retries, next |
| expect | pattern (regex), saveAs, onMatch, onFail (بدونها يفشل التشغيل), next |
| if | variable + (op: lt/gt/le/ge/eq/ne + value) أو pattern، then, else |
| set | variable, value, next |
| delay | ms, next |
| log | text, next |
| cancel | يغلق نافذة USSD، next |
| end | ينهي بنجاح |

الأهداف `next/onMatch/onFail/then/else` = id خطوة، أو `"end"` أو `"fail"`. الافتراضي: الخطوة التالية في القائمة.
يُحفظ ما يلتقطه `expect` في `saveAs` و`saveAs_0`, `saveAs_1`… (مجموعات regex). الأرقام العربية في الردود تُحوَّل تلقائيًا إلى لاتينية قبل المطابقة.

## ملاحظات وحدود
- لم يُترجم هذا المشروع ولم يُختبر على جهاز في بيئة الإنشاء؛ توقّع تعديلات بسيطة عند أول بناء.
- نصوص أزرار نافذة USSD وحزم تطبيق الاتصال تختلف بين الشركات المصنّعة (Samsung/Xiaomi…). عدّل `PKGS` و`CANCEL` في `UssdAccessibilityService` إذا لم تُكتشف النافذة.
- ترتيب `simSlot` مع `callCapablePhoneAccounts` ليس مضمونًا على كل الأجهزة.
- إن كان رد الجلسة التالي مطابقًا حرفيًا للسابق دون إغلاق النافذة فقد يُعتبر مكررًا وينتهي بمهلة.
- Google Play يقيّد استخدام AccessibilityService لغير أدوات الوصول؛ التطبيق مناسب للتوزيع الداخلي/APK مباشر.
- التشغيل يعمل داخل Foreground Service (إشعار دائم بزر إيقاف + WakeLock بسقف 6 ساعات)، فيستمر مع إطفاء الشاشة. على بعض الأجهزة (Xiaomi/Huawei) استثنِ التطبيق من توفير البطارية.
- استخدمه فقط على خطوطك أو بإذن أصحابها.

## البناء على GitHub (CI)
- ملف `.github/workflows/build.yml` يبني APK تلقائيًا عند كل push وpull request ويرفعه كـ Artifact باسم `UssdFlow-debug` (تبويب Actions ← آخر تشغيل ← Artifacts).
- لإصدار Release: `git tag v1.0 && git push origin v1.0` فيُنشأ Release ومعه ملفات APK (الـ release غير موقّع؛ استخدم الـ debug للتثبيت المباشر أو وقّعه بنفسك).
- يمكن التشغيل يدويًا من Actions ← Build APK ← Run workflow.
- لا يحتاج المشروع Gradle Wrapper لأن الـ workflow يثبّت Gradle 8.7. لإضافته محليًا (اختياري): `gradle wrapper --gradle-version 8.7` ثم ارفع `gradlew` و`gradle/`.
- لا ترفع ملفات توقيع (`*.jks`) ولا كلمات مرور إلى المستودع؛ استخدم GitHub Secrets.
