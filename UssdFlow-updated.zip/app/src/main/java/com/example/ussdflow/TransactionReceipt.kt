package com.example.ussdflow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يتعامل فقط مع إيصال ظاهر في رد USSD؛ لا ينشئ رسالة SMS واردة مزيفة ولا يرسل SMS تلقائيًا. */
object TransactionReceipt {
    data class Receipt(val amount: String, val recipient: String, val balance: String, val message: String)

    private const val PREFS = "transaction_receipts"
    private const val KEY_HISTORY = "history"
    private const val CHANNEL = "transaction_receipts"
    private const val NOTIFICATION_ID = 2201

    // يقبل الإيصال المحدد فقط عندما يحتوي الرد على عبارة التحويل والمبلغ والمستلم والرصيد.
    private val pattern = Regex(
        "تم\\s*تحويل\\s*ILS\\s*([0-9]+(?:[.,][0-9]{1,2})?)\\s*الى\\s*(\\+?[0-9]{8,15})\\s*رصيدك\\s*الحالي\\s*ILS\\s*([0-9]+(?:[.,][0-9]{1,2})?)",
        RegexOption.IGNORE_CASE
    )

    fun parse(response: String): Receipt? {
        val normalized = WorkflowEngine.normalizeDigits(response).replace('\u00A0', ' ')
        val m = pattern.find(normalized) ?: return null
        val amount = m.groupValues[1].replace(',', '.')
        val recipient = m.groupValues[2]
        val balance = m.groupValues[3].replace(',', '.')
        val message = "تم تحويل ILS $amount الى $recipient رصيدك الحالي ILS $balance"
        return Receipt(amount, recipient, balance, message)
    }

    fun recordAndNotify(context: Context, receipt: Receipt) {
        save(context, receipt)
        createChannel(context)
        val composeIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", receipt.message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val openMessages = PendingIntent.getActivity(
            context, NOTIFICATION_ID, composeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL)
        else @Suppress("DEPRECATION") Notification.Builder(context)
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تم رصد إيصال تحويل")
            .setContentText(receipt.message)
            .setStyle(Notification.BigTextStyle().bigText(receipt.message))
            .setAutoCancel(true)
            .setContentIntent(openMessages)
            .addAction(Notification.Action.Builder(null, "فتح الرسائل بالنص", openMessages).build())
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun save(context: Context, receipt: Receipt) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val history = runCatching { JSONArray(prefs.getString(KEY_HISTORY, "[]")) }.getOrDefault(JSONArray())
        val item = JSONObject().apply {
            put("timestamp", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
            put("message", receipt.message)
            put("amount", receipt.amount)
            put("recipient", receipt.recipient)
            put("balance", receipt.balance)
        }
        history.put(item)
        // احتفظ بآخر 200 إيصال فقط.
        val trimmed = JSONArray()
        for (i in maxOf(0, history.length() - 199)..history.length() - 1) trimmed.put(history.getJSONObject(i))
        prefs.edit().putString(KEY_HISTORY, trimmed.toString()).apply()
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "إيصالات التحويل", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "إشعارات الإيصالات التي تم التعرف عليها في رد USSD"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
