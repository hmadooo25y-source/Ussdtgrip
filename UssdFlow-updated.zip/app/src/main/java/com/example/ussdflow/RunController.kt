package com.example.ussdflow

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يحمل حالة التشغيل خارج الـ Activity ليستمر عبر تدوير الشاشة. */
object RunController {

    data class RowResult(
        val rowNumber: Int,
        val rowVars: Map<String, String>,
        val result: WorkflowEngine.Result,
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    val logLines = MutableStateFlow<List<String>>(emptyList())
    val running = MutableStateFlow(false)

    @Volatile var workflow: Workflow? = null
    @Volatile var rows: List<Map<String, String>>? = null
    /** متغيرات تُدخل يدويًا من الواجهة (مثل number). قيم CSV تتغلب عليها. */
    @Volatile var extraVars: Map<String, String> = emptyMap()
    /** آخر قيمة name التي التقطها السيناريو، للعرض في الواجهة. */
    val lastName = MutableStateFlow("")
    val results = mutableListOf<RowResult>()

    fun log(line: String) {
        val stamped = "${timeFmt.format(Date())}  $line"
        logLines.value = (logLines.value + stamped).takeLast(1000)
    }

    fun clearLog() { logLines.value = emptyList() }

    fun start(appContext: Context) {
        val wf = workflow ?: return
        if (running.value) return
        synchronized(results) { results.clear() }
        lastName.value = ""
        running.value = true
        UssdBus.armed = true
        if (wf.hideUi && wf.mode != "api") {
            UssdAccessibilityService.instance?.showCover { stop() }
        }
        job = scope.launch {
            val transport = TransportFactory.create(appContext, wf)
            val engine = WorkflowEngine(transport) { log(it) }
            try {
                val data = rows ?: listOf(emptyMap())
                log("▶ ${wf.name} — ${data.size} تشغيل (mode=${wf.mode})")
                for ((i, rawRow) in data.withIndex()) {
                    ensureActive()
                    val row = extraVars + rawRow
                    if (data.size > 1) log("── الصف ${i + 1}/${data.size} $row")
                    val res = engine.run(wf, row)
                    res.vars["name"]?.takeIf { it.isNotBlank() }?.let { lastName.value = it.trim() }
                    synchronized(results) { results.add(RowResult(i + 1, row, res)) }
                    // لا نعرض إيصالًا إلا عند نجاح السيناريو ووجود صيغة إيصال تحويل كاملة في الرد الفعلي.
                    if (res.success) {
                        TransactionReceipt.parse(res.lastResponse)?.let { receipt ->
                            runCatching { TransactionReceipt.recordAndNotify(appContext, receipt) }
                                .onSuccess { log("✓ تم حفظ إيصال التحويل محليًا وإظهار إشعار") }
                                .onFailure { log("⚠ تعذر حفظ/إظهار إيصال التحويل: ${it.message}") }
                        }
                    }
                    if (!res.success && wf.stopOnError) {
                        log("■ توقف بسبب stopOnError")
                        break
                    }
                    if (i < data.size - 1) delay(wf.delayBetweenRowsMs)
                }
                val ok = synchronized(results) { results.count { it.result.success } }
                log("■ اكتمل: نجح $ok من ${synchronized(results) { results.size }}")
            } catch (e: kotlinx.coroutines.CancellationException) {
                log("■ تم الإيقاف")
                throw e
            } catch (e: Exception) {
                log("✗ خطأ غير متوقع: ${e.message}")
            } finally {
                withContext(NonCancellable) {
                    runCatching { transport.close() }
                    UssdAccessibilityService.instance?.hideCover()
                    UssdBus.armed = false
                    running.value = false
                }
            }
        }
    }

    fun stop() { job?.cancel() }

    fun resultsCsv(): String {
        val snapshot = synchronized(results) { results.toList() }
        val inputKeys = snapshot.flatMap { it.rowVars.keys }.distinct()
        val headers = inputKeys + listOf("_status", "_message", "_last_response", "_captured")
        val wfKeys = workflow?.variables?.keys.orEmpty()
        val rows = snapshot.map { r ->
            val captured = r.result.vars
                .filterKeys { it !in wfKeys && it !in inputKeys }
                .entries.joinToString("; ") { "${it.key}=${it.value}" }
            inputKeys.map { r.rowVars[it].orEmpty() } + listOf(
                if (r.result.success) "OK" else "FAIL",
                r.result.message,
                r.result.lastResponse.replace("\n", " "),
                captured,
            )
        }
        return Csv.write(headers, rows)
    }

    fun logText(): String = logLines.value.joinToString("\n")
}
