package com.example.ussdflow

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class UssdAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: UssdAccessibilityService? = null

        private val PKGS = setOf(
            "com.android.phone", "com.android.server.telecom", "com.android.dialer",
            "com.google.android.dialer", "com.samsung.android.incallui",
            "com.samsung.android.dialer", "com.miui.phone", "com.android.incallui",
        )
        private val CANCEL = setOf(
            "cancel", "dismiss", "إلغاء", "الغاء", "ביטול", "annuler", "cancelar", "iptal", "abbrechen",
        )
    }

    private class Collected(
        val texts: List<String>,
        val buttons: List<AccessibilityNodeInfo>,
        val edit: AccessibilityNodeInfo?,
    )

    private var lastText: String? = null
    private var ignoreUntil = 0L

    private var cover: View? = null
    private val main = Handler(Looper.getMainLooper())

    /**
     * طبقة سوداء فوق كل شيء أثناء التشغيل، فلا تظهر نوافذ الاتصال وUSSD.
     * القراءة والكتابة في النافذة تعمل خلفها لأن الخدمة تتعامل مع عناصرها مباشرة.
     * تُزال تلقائيًا عند انتهاء التشغيل أو الإيقاف أو تعطيل الخدمة.
     */
    fun showCover(onStop: () -> Unit) {
        main.post {
            if (cover != null) return@post
            val dp = resources.displayMetrics.density
            val layout = FrameLayout(this).apply {
                setBackgroundColor(0xFF000000.toInt())
                val box = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                }
                box.addView(TextView(context).apply {
                    text = "جارٍ تنفيذ السيناريو…"
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 20f
                    gravity = Gravity.CENTER
                })
                box.addView(Button(context).apply {
                    text = "■ إيقاف"
                    setOnClickListener { onStop() }
                }, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                ).apply { topMargin = (24 * dp).toInt() })
                addView(box, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER,
                ))
            }
            val lp = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE,
            )
            try {
                getSystemService(WindowManager::class.java).addView(layout, lp)
                cover = layout
            } catch (_: Exception) {
            }
        }
    }

    fun hideCover() {
        main.post { removeCoverNow() }
    }

    private fun removeCoverNow() {
        cover?.let {
            try {
                getSystemService(WindowManager::class.java).removeView(it)
            } catch (_: Exception) {
            }
        }
        cover = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeCoverNow()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeCoverNow()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!UssdBus.armed || e == null) return
        val pkg = e.packageName?.toString()
        if (pkg == null || pkg !in PKGS) {
            lastText = null
            return
        }
        if (SystemClock.uptimeMillis() < ignoreUntil) return
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() !in PKGS) {
            lastText = null
            return
        }
        val c = collect(root)
        if (c.edit == null && c.buttons.isEmpty()) {
            lastText = null
            return
        }
        val text = c.texts.joinToString("\n")
        if (text.isBlank() && c.edit == null) return
        if (text == lastText) return
        lastText = text
        UssdBus.screens.tryEmit(UssdScreen(text, c.edit != null))
    }

    private fun collect(root: AccessibilityNodeInfo): Collected {
        val texts = mutableListOf<String>()
        val buttons = mutableListOf<AccessibilityNodeInfo>()
        var edit: AccessibilityNodeInfo? = null

        fun walk(n: AccessibilityNodeInfo) {
            val cls = n.className?.toString().orEmpty()
            when {
                cls.endsWith("EditText") -> if (edit == null) edit = n
                cls.endsWith("Button") -> buttons += n
                cls.endsWith("TextView") -> {
                    val t = n.text?.toString()?.trim().orEmpty()
                    if (t.isNotEmpty()) texts += t
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        return Collected(texts, buttons, edit)
    }

    private fun isCancel(n: AccessibilityNodeInfo): Boolean =
        n.text?.toString()?.trim()?.lowercase() in CANCEL

    private fun usableRoot(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return if (root.packageName?.toString() in PKGS) root else null
    }

    /** يكتب الرد في الحقل ويضغط زر الإرسال. يجب استدعاؤها من الخيط الرئيسي. */
    fun reply(text: String): Boolean {
        val root = usableRoot() ?: return false
        val c = collect(root)
        val edit = c.edit ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return false
        val send = c.buttons.firstOrNull { !isCancel(it) } ?: return false
        // تجاهل الأحداث القصيرة بعد الضغط حتى لا تُقرأ النافذة القديمة كأنها رد جديد
        ignoreUntil = SystemClock.uptimeMillis() + 400
        lastText = null
        return send.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    /** يغلق نافذة USSD الحالية (إلغاء أو موافق). */
    fun dismiss() {
        val root = usableRoot() ?: return
        val c = collect(root)
        val btn = c.buttons.firstOrNull { isCancel(it) } ?: c.buttons.firstOrNull() ?: return
        btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        lastText = null
    }
}
