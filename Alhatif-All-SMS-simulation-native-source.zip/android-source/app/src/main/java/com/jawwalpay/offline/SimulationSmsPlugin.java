package com.jawwalpay.offline;

import android.content.ContentValues;
import android.net.Uri;
import android.provider.Telephony;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SimulationSms")
public class SimulationSmsPlugin extends Plugin {
    @PluginMethod
    public void addToInbox(PluginCall call) {
        String address = call.getString("address", "محاكاة محلية");
        String body = call.getString("body", "");
        if (body.trim().isEmpty() || !body.contains("محاكاة فقط")) {
            call.reject("يُسمح بإضافة رسائل موسومة بوضوح بأنها محاكاة فقط.");
            return;
        }
        try {
            String defaultPackage = Telephony.Sms.getDefaultSmsPackage(getContext());
            if (!getContext().getPackageName().equals(defaultPackage)) {
                call.reject("لا يمكن الكتابة إلى صندوق SMS في Android إلا إذا كان التطبيق هو تطبيق الرسائل الافتراضي. لم تُضف أي رسالة.");
                return;
            }
            ContentValues values = new ContentValues();
            values.put("address", address);
            values.put("body", body);
            values.put("date", System.currentTimeMillis());
            values.put("read", 0);
            values.put("seen", 0);
            Uri uri = getContext().getContentResolver().insert(Uri.parse("content://sms/inbox"), values);
            if (uri == null) {
                call.reject("لم يؤكد Android إضافة الرسالة إلى صندوق الوارد.");
                return;
            }
            JSObject result = new JSObject();
            result.put("message", "أُضيفت رسالة محاكاة محلية. لا توجد عملية تحويل حقيقية.");
            result.put("simulation", true);
            call.resolve(result);
        } catch (Exception e) {
            call.reject("تعذرت إضافة رسالة المحاكاة إلى صندوق SMS: " + e.getMessage());
        }
    }
}
